<?php

    $server = "localhost";
    $nombre = "root";
    $contrasenia = "";
    $base="examen_registro";

    $con = new mysqli($server, $nombre, $contrasenia, $base);

    if ($con->connect_error) {
        die("La conexión a la base de datos ha fallado, dando este código de error: " . $con->connect_error);
    }
    

    $sql = "SELECT * FROM registros";

    $resultado = $con->query($sql);

    //Si hay más de 0 columnas
    /*if ($resultado->num_rows > 0) {

        while($columna = $result->fetch_assoc()) {
            $respuesta = $columna["predicion"] + $columna["fechanacimiento"] + $columna["genero"] + $columna["email"] + "\n";
        }
    }*/


    //INSTRUCCIONES AÑADIDAS
    $datos = [];
    foreach($resultado as $elemento){
        array_push($datos, $elemento);
    }

    $json = json_encode($datos, JSON_UNESCAPED_UNICODE);
    echo "$json";


    
    //echo $respuesta;

    $con->close();
    


?>