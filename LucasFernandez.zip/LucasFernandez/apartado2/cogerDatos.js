function cogerDatos() {


    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200){
            
            var datosPersona = this.response;

            //INSTRUCCION ERRONEA
            //var body = document.getElementById("principal");

            //INSTRUCCIÓN AÑADIDA
            document.getElementById("datos").textContent = datosPersona;

           // body.append(datosPersona);

        }

    };
    
    xhttp.open("GET", "cogerDatos.php", true);
    xhttp.send();

    return false;

}